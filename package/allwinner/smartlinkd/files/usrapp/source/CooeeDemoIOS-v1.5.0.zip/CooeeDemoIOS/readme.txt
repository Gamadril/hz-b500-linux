* How to integrate COOEE IOS application?

Copy libcooee.a/libcrypto.a/cooee.h to your project, and call send_cooee() in your code.

* Interface definition

int set_packet_interval(int ms);
set packet interval in ms, default 8ms.

int send_cooee(const char* ssid, int ssid_len, /* ssid and len */
    const char* pwd, int pwd_len,  /* password and len */
    const char* key, int key_len,  /* encryption key and len, leave it "" to use default */
    unsigned int ip); /* ip address in network order */
send cooee a round. Parameters:
  - ssid: AP's SSID
  - pwd: AP's password
  - key: encryption key. To use default encryption key, just leave it "" or NULL and set key_len to 0.
  - ip: IP address in network order, so for 192.168.1.1 it should be 0x0101a8c0
